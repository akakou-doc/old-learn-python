import hoge

# 0 が表示される
print(hoge.piyo)

# ohayo が表示される。
hoge.greet()
