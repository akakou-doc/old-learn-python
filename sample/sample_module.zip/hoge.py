piyo = 0

def greet():
    print('ohayo!')

